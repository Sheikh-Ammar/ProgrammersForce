<?php
// REQUIRE INIT FILE
require_once '../app/init.php';

// CRETE CORE/APP CLASS OBJECT
$app = new App;
