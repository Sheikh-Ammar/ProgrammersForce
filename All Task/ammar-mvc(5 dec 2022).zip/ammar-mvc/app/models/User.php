<?php

// USER MODEL
class User
{
    // USER TABLE COULMNS USE IN HOME  CONTROLLER
    public $id = 0;
    public $email;
    public $password;
}
