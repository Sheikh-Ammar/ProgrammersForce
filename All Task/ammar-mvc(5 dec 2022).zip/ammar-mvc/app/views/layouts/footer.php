<!-- FOOTER -->






<footer class="container-fluid p-3 bg-dark text-white mt-5 text-center">
    <div class="d-flex justify-content-center">
        <a href="/ammar-mvc/public/" class="nav-link active">Home</a>
        <a href="/ammar-mvc/public/about" class="nav-link active">About</a>
        <a href="/ammar-mvc/public/contact" class="nav-link active">Contact</a>
    </div>
    <h3 class="my-2"><i><b>Made BY AMMAR AHMAD</b></i></h3>
</footer>


<!-- Option 1: Bootstrap Bundle with Popper -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
</body>

</html>