<?php include 'layouts/header.php'; ?>


<div class="container mt-5">
    <div class="row">
        <h1 class="text-center">This is CONTACT PAGE</h1>
    </div>
</div>

<?php include  'layouts/footer.php' ?>