<?php

// CONTACT CONTROLLER
class Contact extends Controller
{
    // SHOW CONTACT PAGE
    public function index()
    {
        $this->view('contact');
    }
}
