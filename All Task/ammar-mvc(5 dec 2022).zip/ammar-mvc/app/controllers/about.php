<?php

// ABOUT CONTROLLER
class About extends Controller
{
    // SHOW ABOUT PAGE
    public function index()
    {
        $this->view('about');
    }
}
